const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'secret123',
  resave: false,
  saveUninitialized: true
}));

// Initialize DB
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) return console.error(err.message);
  console.log('Connected to SQLite database.');
});

// Create tables if not exists
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    type TEXT,
    rate REAL,
    min INTEGER,
    max INTEGER
  )`);
});

// Insert default admin user if not exists
const adminUsername = process.env.ADMIN_USERNAME || 'admin';
const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';

function createAdminUser() {
  db.get("SELECT * FROM users WHERE username = ?", [adminUsername], (err, row) => {
    if (err) return console.error(err.message);
    if (!row) {
      bcrypt.hash(adminPassword, 10, (err, hash) => {
        if (err) return console.error(err.message);
        db.run("INSERT INTO users (username, password) VALUES (?, ?)", [adminUsername, hash]);
        console.log('Admin user created.');
      });
    } else {
      console.log('Admin user exists.');
    }
  });
}

// Load services from CSV only if no services exist
function loadServicesFromCSV() {
  db.get("SELECT COUNT(*) as count FROM services", (err, row) => {
    if (err) return console.error(err.message);
    if (row.count === 0) {
      const results = [];
      fs.createReadStream('./sample_services.csv')
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => {
          const stmt = db.prepare("INSERT INTO services (name, type, rate, min, max) VALUES (?, ?, ?, ?, ?)");
          for (const service of results) {
            stmt.run(service.name, service.type, parseFloat(service.rate), parseInt(service.min), parseInt(service.max));
          }
          stmt.finalize();
          console.log('Services imported from CSV');
        });
    } else {
      console.log('Services already loaded.');
    }
  });
}

createAdminUser();
loadServicesFromCSV();

// Middleware to check if logged in
function checkAuth(req, res, next) {
  if (req.session.userId) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Routes

app.get('/', (req, res) => {
  if (req.session.userId) {
    res.redirect('/dashboard');
  } else {
    res.redirect('/login');
  }
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get("SELECT * FROM users WHERE username = ?", [username], (err, user) => {
    if (err) return res.render('login', { error: "Database error." });
    if (!user) return res.render('login', { error: "Invalid username or password." });

    bcrypt.compare(password, user.password, (err, result) => {
      if (result) {
        req.session.userId = user.id;
        req.session.username = user.username;
        res.redirect('/dashboard');
      } else {
        res.render('login', { error: "Invalid username or password." });
      }
    });
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

app.get('/dashboard', checkAuth, (req, res) => {
  db.all("SELECT * FROM services", (err, services) => {
    if (err) return res.send('DB Error');
    res.render('dashboard', { username: req.session.username, services });
  });
});

// Add more routes as needed...

app.listen(PORT), () => 
console.log('Server running on http://localhost:' + PORT);
app.get('/admin/users', checkAuth, (req, res) => {
  db.all("SELECT id, username FROM users", (err, users) => {
    if (err) return res.send('DB Error');
    res.render('users', { username: req.session.username, users });
  });
});
app.post('/order', checkAuth, (req, res) => {
  const { service_id, quantity } = req.body;
  db.run("INSERT INTO orders (user_id, service_id, quantity, status) VALUES (?, ?, ?, ?)", 
    [req.session.userId, service_id, quantity, 'pending'], 
    function(err) {
      if (err) return res.send('Order failed.');
      res.send('Order placed successfully!');
    });
});
db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    service_id INTEGER,
    quantity INTEGER,
    status TEXT
  )`);
  app.post('/order', checkAuth, (req, res) => {
  const { service_id, quantity } = req.body;
  db.run("INSERT INTO orders (user_id, service_id, quantity, status) VALUES (?, ?, ?, ?)", 
    [req.session.userId, service_id, quantity, 'pending'], 
    function(err) {
      if (err) return res.send('Order failed.');
      res.send('Order placed successfully!');
    });
});
app.get('/orders', checkAuth, (req, res) => {
  db.all(`SELECT orders.id, services.name AS service_name, orders.quantity, orders.status 
          FROM orders 
          JOIN services ON orders.service_id = services.id 
          WHERE orders.user_id = ?`, 
    [req.session.userId], 
    (err, orders) => {
      if (err) return res.send('DB Error');
      res.render('orders', { orders });
    });
});
cookie: { maxAge: 30 * 60 * 1000 } // 50 minutes
function isAdmin(req, res, next) {
  if (req.session.username === process.env.ADMIN_USERNAME) {
    return next();
  }
  return res.status(403).send("Forbidden");
}
app.get('/admin/services', checkAuth, isAdmin, (req, res) => {  });
app.get('/dashboard', checkAuth, (req, res) => {
  db.get("SELECT balance FROM users WHERE id = ?", [req.session.userId], (err, user) => {
    if (err) return res.send('User Error');
    db.all("SELECT * FROM services", (err, services) => {
      if (err) return res.send('Service Error');
      res.render('dashboard', { 
        username: req.session.username, 
        services, 
        balance: user.balance || 0 
      });
    });
  });
});
db.run(`CREATE TABLE IF NOT EXISTS recharges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    amount REAL,
    utr TEXT,
    status TEXT DEFAULT 'pending'
)`);
// Recharge Page
app.get('/recharge', checkAuth, (req, res) => {
  res.render('recharge', { username: req.session.username });
});

app.post('/recharge', checkAuth, (req, res) => {
  const { amount, utr } = req.body;
  db.run("INSERT INTO recharges (user_id, amount, utr, status) VALUES (?, ?, ?, 'pending')",
    [req.session.userId, amount, utr],
    (err) => {
      if (err) return res.send("Recharge request failed.");
      res.send("Recharge request submitted! Wait for admin approval.");
    });
});

// Admin - View Recharges
app.get('/admin/recharges', checkAuth, isAdmin, (req, res) => {
  db.all(`SELECT recharges.id, users.username, recharges.amount, recharges.utr, recharges.status
          FROM recharges
          JOIN users ON recharges.user_id = users.id`, (err, rows) => {
    if (err) return res.send("DB Error");
    res.render('admin_recharges', { username: req.session.username, recharges: rows });
  });
});

// Admin - Approve Recharge
app.post('/admin/recharges/:id/approve', checkAuth, isAdmin, (req, res) => {
  const rechargeId = req.params.id;
  db.get("SELECT * FROM recharges WHERE id = ?", [rechargeId], (err, recharge) => {
    if (!recharge) return res.send("Recharge not found.");
    db.run("UPDATE users SET balance = balance + ? WHERE id = ?", [recharge.amount, recharge.user_id], () => {
      db.run("UPDATE recharges SET status = 'approved' WHERE id = ?", [rechargeId], () => {
        res.redirect('/admin/recharges');
      });
    });
  });
});
